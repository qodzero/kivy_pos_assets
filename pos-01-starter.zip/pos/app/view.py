
from kivy.uix.boxlayout import BoxLayout

class MainWindow(BoxLayout):
    def __init__(self, **kw):
        super().__init__(**kw)
